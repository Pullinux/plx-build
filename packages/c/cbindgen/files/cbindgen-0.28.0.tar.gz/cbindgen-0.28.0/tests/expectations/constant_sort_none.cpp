#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <ostream>
#include <new>

constexpr static const uint8_t B = 0;

constexpr static const uint8_t A = 0;

extern "C" {

extern const uint8_t D;

extern const uint8_t C;

}  // extern "C"
