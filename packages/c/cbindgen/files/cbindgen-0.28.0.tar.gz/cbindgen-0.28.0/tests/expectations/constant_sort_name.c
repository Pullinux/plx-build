#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>

#define A 0

#define B 0

extern const uint8_t C;

extern const uint8_t D;
