#include <cstdarg>
#include <cstdint>
#include <cstdlib>
#include <ostream>
#include <new>

extern "C" {

/// The root of all evil.
void root();

/// A little above the root, and a lot more visible, with a run-on sentence
void trunk();

}  // extern "C"
