var searchData=
[
  ['paintcontext_0',['PaintContext',['https://doc.qt.io/qt-5/qabstracttextdocumentlayout-paintcontext.html',1,'QAbstractTextDocumentLayout']]],
  ['pixmapfragment_1',['PixmapFragment',['https://doc.qt.io/qt-5/qpainter-pixmapfragment.html',1,'QPainter']]],
  ['private_2',['private',['../classKDSoapPendingCall_1_1Private.html',1,'KDSoapPendingCall::Private'],['../classKDSoapPendingCallWatcher_1_1Private.html',1,'KDSoapPendingCallWatcher::Private']]]
];
