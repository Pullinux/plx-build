var searchData=
[
  ['tab_0',['Tab',['https://doc.qt.io/qt-5/qtextoption-tab.html',1,'QTextOption']]],
  ['takerowresult_1',['TakeRowResult',['https://doc.qt.io/qt-5/qformlayout-takerowresult.html',1,'QFormLayout']]],
  ['timerinfo_2',['TimerInfo',['https://doc.qt.io/qt-5/qabstracteventdispatcher-timerinfo.html',1,'QAbstractEventDispatcher']]],
  ['touchpoint_3',['TouchPoint',['https://doc.qt.io/qt-5/qtouchevent-touchpoint.html',1,'QTouchEvent']]]
];
