var searchData=
[
  ['httpresponseheaderitem_0',['HttpResponseHeaderItem',['../structKDSoapServerObjectInterface_1_1HttpResponseHeaderItem.html',1,'KDSoapServerObjectInterface']]]
];
