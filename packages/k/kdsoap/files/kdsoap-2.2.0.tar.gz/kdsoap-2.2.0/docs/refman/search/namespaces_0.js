var searchData=
[
  ['kdsoap_0',['KDSoap',['../namespaceKDSoap.html',1,'']]],
  ['kdsoapmessagerelationship_1',['KDSoapMessageRelationship',['../namespaceKDSoapMessageRelationship.html',1,'']]]
];
