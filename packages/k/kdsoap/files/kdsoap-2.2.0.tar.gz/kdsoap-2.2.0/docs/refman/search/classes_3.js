var searchData=
[
  ['element_0',['Element',['https://doc.qt.io/qt-5/qpainterpath-element.html',1,'QPainterPath']]],
  ['extraselection_1',['ExtraSelection',['https://doc.qt.io/qt-5/qtextedit-extraselection.html',1,'QTextEdit']]]
];
