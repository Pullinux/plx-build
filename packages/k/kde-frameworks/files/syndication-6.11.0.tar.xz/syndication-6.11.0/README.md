# Syndication

An RSS/Atom parser library

## Introduction

RSS (0.9/1.0, 0.91..2.0) and Atom (0.3 and 1.0) feeds are supported.
syndication offers a unified, format-agnostic view on the parsed feed, 
so that the using application does not need to distinguish between feed
formats.
