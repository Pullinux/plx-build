# KTextWidgets

Text editing widgets

## Introduction

KTextWidgets provides widgets for displaying and editing text. It supports
rich text as well as plain text.

