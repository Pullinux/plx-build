[KCM Locale]
Name=French
