v.setCursorPosition(1,5);
v.enter();
v.type("constructor");
