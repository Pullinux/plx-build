v.setCursorPosition(0, document.lineLength(0));
v.enter();
v.type("return 1");
