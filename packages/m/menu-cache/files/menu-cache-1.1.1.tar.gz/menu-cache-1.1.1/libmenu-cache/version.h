#ifndef __MENU_CACHE_VER_H__
#define __MENU_CACHE_VER_H__

/* change these numbers if you change enums in menu-cache.h
   note that will break compatibility for generated cache */
#define VER_MAJOR	1
#define VER_MINOR	2
/* This is for backward compatibility on transitions */
#define VER_MINOR_SUPPORTED 1

#endif
