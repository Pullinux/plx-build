all
rule 'MD007', :indent => 2, :start_indented => false
rule 'MD013', :line_length => 100, :tables => false
rule 'MD029', :style => :ordered
exclude_rule 'MD033'
