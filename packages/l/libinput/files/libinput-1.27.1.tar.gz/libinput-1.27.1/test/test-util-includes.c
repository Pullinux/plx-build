/* compile test for the util files */
#include @FILE@

int main(void) {
	return 0;
}
