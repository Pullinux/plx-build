#include <libinput.h>

/* This is a build-test only */

int
main(void)
{
	return 0;
}
