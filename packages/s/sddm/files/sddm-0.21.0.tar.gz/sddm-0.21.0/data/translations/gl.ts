<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS>
<context>
    <name>PictureBox</name>
    <message>
        <source>Press to login</source>
        <translation>Prema para acceder</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>%1 (Wayland)</source>
        <translation>%1 (Wayland)</translation>
    </message>
</context>
<context>
    <name>TextConstants</name>
    <message>
        <source>Welcome to %1</source>
        <translation>Dámoslle a benvida a %1</translation>
    </message>
    <message>
        <source>Warning, Caps Lock is ON!</source>
        <translation>Aviso, as maiúsculas están BLOQUEADAS!</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>Disposición</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Acceder</translation>
    </message>
    <message>
        <source>Login failed</source>
        <translation>O acceso fallou</translation>
    </message>
    <message>
        <source>Login succeeded</source>
        <translation>Accedeuse</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Contrasinal</translation>
    </message>
    <message>
        <source>Enter your username and password</source>
        <translation>Escriba o seu nome de persoa usuaria e contrasinal</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation>Reiniciar</translation>
    </message>
    <message>
        <source>Session</source>
        <translation>Sesión</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Usuaria</translation>
    </message>
    <message>
        <source>Select your user and enter password</source>
        <translation>Seleccione a súa conta e escriba o contrasinal</translation>
    </message>
</context>
</TS>
