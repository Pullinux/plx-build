<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ca">
<context>
    <name>PictureBox</name>
    <message>
        <source>Press to login</source>
        <translation>Feu clic per iniciar la sessió</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <source>%1 (Wayland)</source>
        <translation>%1 (Wayland)</translation>
    </message>
</context>
<context>
    <name>TextConstants</name>
    <message>
        <source>Welcome to %1</source>
        <translation>Benvingut/da a %1</translation>
    </message>
    <message>
        <source>Warning, Caps Lock is ON!</source>
        <translation>Compte, el bloqueig de majúscules està activat!</translation>
    </message>
    <message>
        <source>Layout</source>
        <translation>Disposició</translation>
    </message>
    <message>
        <source>Login</source>
        <translation>Inicia la sessió</translation>
    </message>
    <message>
        <source>Login failed</source>
        <translation>Inici de sessió no reeixit</translation>
    </message>
    <message>
        <source>Login succeeded</source>
        <translation>Inici de sessió reeixit</translation>
    </message>
    <message>
        <source>Password</source>
        <translation>Contrasenya</translation>
    </message>
    <message>
        <source>Enter your username and password</source>
        <translation>Introduïu el vostre usuari i contrasenya</translation>
    </message>
    <message>
        <source>Reboot</source>
        <translation>Reinicia</translation>
    </message>
    <message>
        <source>Session</source>
        <translation>Sessió</translation>
    </message>
    <message>
        <source>Shutdown</source>
        <translation>Apaga</translation>
    </message>
    <message>
        <source>Username</source>
        <translation>Usuari</translation>
    </message>
    <message>
        <source>Select your user and enter password</source>
        <translation>Seleccioneu el vostre usuari i introduïu la contrasenya</translation>
    </message>
</context>
</TS>
