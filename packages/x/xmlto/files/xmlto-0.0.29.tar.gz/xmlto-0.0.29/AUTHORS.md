Author: Tim Waugh <twaugh@redhat.com>

since 0.0.19 maintained by Ondrej Vasik <ovasik@redhat.com>
since 0.0.29 maintained by Ondrej Sloup <osloup@redhat.com>
