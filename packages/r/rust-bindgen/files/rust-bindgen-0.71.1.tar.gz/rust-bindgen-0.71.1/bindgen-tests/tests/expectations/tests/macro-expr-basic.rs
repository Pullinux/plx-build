#![allow(dead_code, non_snake_case, non_camel_case_types, non_upper_case_globals)]
pub const FOO: u32 = 1;
pub const BAR: u32 = 4;
pub const BAZ: u32 = 5;
pub const MIN: i64 = -9223372036854775808;
pub const BARR: u32 = 1;
pub const BAZZ: u32 = 7;
pub const I_RAN_OUT_OF_DUMB_NAMES: u32 = 7;
pub const HAZ_A_COMMENT: u32 = 1;
pub const HAZ_A_COMMENT_INSIDE: u32 = 2;
