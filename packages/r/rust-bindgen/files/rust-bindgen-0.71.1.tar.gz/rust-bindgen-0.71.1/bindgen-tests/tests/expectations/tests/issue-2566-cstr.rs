#![allow(dead_code, non_snake_case, non_camel_case_types, non_upper_case_globals)]
pub const FOO: &[u8; 4] = b"a\0b\0";
