#![allow(dead_code, non_snake_case, non_camel_case_types, non_upper_case_globals)]
pub const CONST: u32 = 5;
pub const OTHER_CONST: u32 = 6;
pub const LARGE_CONST: u32 = 1536;
