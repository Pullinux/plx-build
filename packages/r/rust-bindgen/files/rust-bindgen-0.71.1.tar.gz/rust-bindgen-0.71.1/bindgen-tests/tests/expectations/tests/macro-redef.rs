#![allow(dead_code, non_snake_case, non_camel_case_types, non_upper_case_globals)]
pub const FOO: u32 = 4;
pub const BAR: u32 = 5;
pub const BAZ: u32 = 6;
