#![allow(dead_code, non_snake_case, non_camel_case_types, non_upper_case_globals)]
pub const Enum_Variant: Enum = 0;
pub type Enum = i16;
pub type TypedefFirst = i16;
pub const TypedefFirst_Variant2: TypedefFirst = 0;
