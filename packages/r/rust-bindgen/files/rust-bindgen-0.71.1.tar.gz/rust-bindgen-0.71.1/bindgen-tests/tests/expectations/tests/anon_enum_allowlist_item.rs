#![allow(dead_code, non_snake_case, non_camel_case_types, non_upper_case_globals)]
pub const NODE_FLAG_FOO: _bindgen_ty_1 = 0;
pub const NODE_FLAG_BAR: _bindgen_ty_1 = 1;
pub type _bindgen_ty_1 = ::std::os::raw::c_uint;
