#![allow(dead_code, non_snake_case, non_camel_case_types, non_upper_case_globals)]
pub const INFINITY: f64 = f64::INFINITY;
pub const NAN: f64 = f64::NAN;
