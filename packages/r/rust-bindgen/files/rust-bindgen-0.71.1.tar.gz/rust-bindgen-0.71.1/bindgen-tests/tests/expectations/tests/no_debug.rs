#![allow(dead_code, non_snake_case, non_camel_case_types, non_upper_case_globals)]
/// <div rustbindgen nodebug></div>
#[repr(C)]
#[derive(Default, Copy, Clone)]
pub struct DebugButWait {
    pub whatever: ::std::os::raw::c_int,
}
