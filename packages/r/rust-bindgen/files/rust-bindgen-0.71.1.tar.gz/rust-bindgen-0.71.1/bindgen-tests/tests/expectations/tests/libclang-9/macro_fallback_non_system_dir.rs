pub const NEGATIVE: i32 = -1;
