#![allow(dead_code, non_snake_case, non_camel_case_types, non_upper_case_globals)]
pub const NONE: u32 = 0;
pub const FOO: u32 = 5;
pub const FOOB: i32 = -2;
pub const FOOBAR: i32 = -10;
