# Generated C, C++, Header files

This directory contains files for features where extra files are generated
as a part of the feature. For example, `--wrap-static-fns`.
