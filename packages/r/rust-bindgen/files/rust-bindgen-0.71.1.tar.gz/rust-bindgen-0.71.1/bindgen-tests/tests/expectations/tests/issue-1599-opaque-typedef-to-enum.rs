#![allow(dead_code, non_snake_case, non_camel_case_types, non_upper_case_globals)]
pub const a_b: a = 0;
pub const a_c: a = 1;
pub type a = ::std::os::raw::c_uint;
pub type d = u32;
