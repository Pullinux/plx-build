#![allow(dead_code, non_snake_case, non_camel_case_types, non_upper_case_globals)]
pub const RENAMED_MyVal: _bindgen_ty_1 = 0;
pub type _bindgen_ty_1 = ::std::os::raw::c_uint;
