include!(concat!(
    env!("OUT_DIR"),
    "/libclang_version_specific_generated_tests.rs"
));
