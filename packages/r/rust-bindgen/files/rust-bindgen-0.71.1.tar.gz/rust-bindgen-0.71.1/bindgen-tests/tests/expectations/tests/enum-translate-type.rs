#![allow(dead_code, non_snake_case, non_camel_case_types, non_upper_case_globals)]
pub const my_enum1_A: my_enum1 = 0;
pub type my_enum1 = u32;
pub const my_enum2_B: my_enum2 = -1;
pub type my_enum2 = i32;
pub const my_enum3_C: my_enum3 = 0;
pub type my_enum3 = i16;
pub const my_enum4_D: my_enum4 = 255;
pub type my_enum4 = u8;
