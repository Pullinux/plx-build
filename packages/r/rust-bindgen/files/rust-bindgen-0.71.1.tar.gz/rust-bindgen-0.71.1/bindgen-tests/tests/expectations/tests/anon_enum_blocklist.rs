#![allow(dead_code, non_snake_case, non_camel_case_types, non_upper_case_globals)]
pub const FLAG_Z: _bindgen_ty_2 = 0;
pub const FLAG_W: _bindgen_ty_2 = 1;
pub type _bindgen_ty_2 = ::std::os::raw::c_uint;
